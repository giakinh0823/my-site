
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({
          navigation : true,
          items : 1, 
          loop:true,
            nav:false,
            // animateOut: 'fadeOut',
            // animateIn: 'fadeIn',
        });
      });
